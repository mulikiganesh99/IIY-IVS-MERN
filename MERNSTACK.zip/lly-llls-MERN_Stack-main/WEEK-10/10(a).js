function App() {
  return (
    <div>
      <h1>Welcome to React</h1>
      <p>This HTML is rendered using React.</p>
    </div>
  );
}

export default App;