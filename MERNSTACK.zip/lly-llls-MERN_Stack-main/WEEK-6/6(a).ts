// Simple Types
let studentId: number = 101;
let studentName: string = "Rahul";
let isPresent: boolean = true;

// Special Types
let valueAny: any = "Hello";
valueAny = 123;   // allowed

let valueUnknown: unknown = "TypeScript";

// void type (used in functions)
function displayMessage(): void {
    console.log("Welcome to TypeScript");
}

// null and undefined
let emptyValue: null = null;
let notAssigned: undefined = undefined;

// Function call
displayMessage();